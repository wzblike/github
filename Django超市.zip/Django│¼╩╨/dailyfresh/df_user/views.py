from django.shortcuts import render, redirect, get_object_or_404
from df_user.forms import UserForm
from hashlib import sha1
from df_user.models import UserInfo, UserAddressInfo
from django.http import JsonResponse
from df_goods.models import *


def is_login(func):
    # 判断是否登录状态的装饰器
    def inner(request, *args, **kwargs):
        if request.session.get('user_id'):
            # 如果用户已登录
            return func(request, *args, **kwargs)
        else:
            # 如果没有登录 重定向到登录页面
            if request.is_ajax():
                return JsonResponse({'isLogin': 0})
            return redirect('login')

    return inner


# Create your views here.
def register(request):
    form = UserForm()
    return render(request, 'df_user/register.html', {'form': form})


def check_register(request):
    dict1 = request.POST
    upwd = dict1.get('upwd')
    form = UserForm(request.POST)
    # 用表单is_valid就帮我们验证了
    if form.is_valid():
        user = form.save(commit=False)
        s1 = sha1()
        s1.update(upwd.encode())
        upwd = s1.hexdigest()  # 获取到加密后的密码
        user.upwd = upwd
        user.save()  # 注册成功
        return redirect('login')
    return render(request, 'df_user/register.html', {'form': form})

#用户名是否存在
def user_check(request):
    uname = request.GET.get('uname')
    xxx = UserInfo.objects.filter(uname=uname).count()  # 根据用户名查找用户 个数
    return JsonResponse({'num': xxx})


def login(request):
    uname = request.COOKIES.get('uname')
    request.session['login_from'] = request.META.get('HTTP_REFERER')  # 来到此视图之前的一个请求地址

    return render(request, 'df_user/login.html', {'title': '登录', 'error_name': 0, 'error_pwd': 0, 'uname': uname})


def login_check(request):
    dict1 = request.POST
    uname = dict1.get('username')
    upwd = dict1.get('pwd')
    jizhu = dict1.get('jizhu', 0)#记住用户名
    users = UserInfo.objects.filter(uname=uname)  # 根据用户名查找用户
    if users:
        s1 = sha1()
        s1.update(upwd.encode())
        if s1.hexdigest() == users[0].upwd:#加密后的密码相等
            # 登录成功
            # res = redirect('info')  # 跳转到用户中心
            res = redirect(request.session['login_from'])  # 跳转到登录前的页面
            if jizhu:
                # 如果点了记住用户名
                res.set_cookie('uname', uname)
            else:
                res.set_cookie('uname', uname, max_age=-1)  # 到浏览器关闭
            request.session['user_id'] = users[0].id
            request.session['user_name'] = uname
            return res
        else:
            # 密码不对
            context = {'title': '登录', 'error_name': 0, 'error_pwd': 1, 'uname': uname}
            return render(request, 'df_user/login.html', context)
    else:
        # 没有找到用户
        context = {'title': '登录', 'error_name': 1, 'error_pwd': 0, 'uname': uname}
        return render(request, 'df_user/login.html', context)


@is_login#登录能上的就挂上
def info(request):
    id = request.session.get('user_id')
    user = UserInfo.objects.get(id=id)
    #user_addr = UserAddressInfo.objects.get(user=user)
    user_addr = get_object_or_404(UserAddressInfo, user_id=user.id)
    # 最近浏览
    jin = request.COOKIES.get('jin', '[]')
    jin_list = eval(jin)
    # [30, 29, 10]
    goods = [GoodsInfo.objects.get(pk=id) for id in jin_list]

    return render(request, 'df_user/user_center_info.html', {'title': '用户中心', 'goods': goods, 'user_addr': user_addr})


@is_login
def site(request):
    id = request.session.get('user_id')
    print('--------------------------------')
    print(id)
    user = UserInfo.objects.get(id=id)
    user_addr = user.useraddressinfo_set.all()#查询收件人信息
    str1 = ''
    if user_addr:
        user_addr = user_addr[0]
        str1 = f'{user_addr.uaddress},({user_addr.uname})收,电话:{user_addr.uphone}'
    return render(request, 'df_user/user_center_site.html', {'str1': str1})


@is_login
def order(request):

    return render(request, 'df_user/user_center_order.html',)


def shou_save(request):
    dict1 = request.POST#获取收件人信息
    ushou = dict1.get('shou')
    uaddr = dict1.get('addr')
    ucode = dict1.get('ucode')
    uphone = dict1.get('uphone')
    id = request.session.get('user_id')
    user = UserInfo.objects.get(id=id)
    u_addr = UserAddressInfo()#保存收件人信息
    u_addr.uname = ushou
    u_addr.uaddress = uaddr
    u_addr.uphone = uphone
    u_addr.user = user
    u_addr.save()
    return redirect('site')
