from django.apps import AppConfig


class DfUserConfig(AppConfig):
    name = 'df_user'
