from django.apps import AppConfig


class DfGoodsConfig(AppConfig):
    name = 'df_goods'
