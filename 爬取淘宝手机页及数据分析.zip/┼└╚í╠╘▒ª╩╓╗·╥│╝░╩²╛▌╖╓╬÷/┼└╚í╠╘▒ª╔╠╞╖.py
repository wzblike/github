from selenium import webdriver
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait
from urllib.parse import quote
#使用无头浏览器
chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument('--headless')
browser = webdriver.Chrome(chrome_options=chrome_options)

wait = WebDriverWait(browser,10)

KEYWOED = '手机'
#连接MongoDB数据库
import pymongo
MONGO_URL = 'localhost'
#设置库
MONGO_DB = 'taobao'
#设置集合
MONGO_COLLECTION = 'phone'
client = pymongo.MongoClient(MONGO_URL)
db = client[MONGO_DB]

def save_to_mongo(result):
    """
    保存至MongoDB
    :param result: 结果
    """
    try:
        if db[MONGO_COLLECTION].insert(result):
            print('存储到MongoDB成功')
    except Exception:
        print('存储到MongoDB失败')
def index_page(page):
    '''

    :param page:页码
    :return:
    '''
    print("正在爬取第",page,'页')
    try:
        #在搜索时提交关键词,quote是url编码
        url = 'https://re.taobao.com/search?keyword='+quote(KEYWOED)
        browser.get(url)
        if page > 1:
            #选择页码
            input = wait.until(
                EC.presence_of_element_located((By.CSS_SELECTOR,'#Jumper')))
            #选择点击按钮
            submit = wait.until(
                EC.element_to_be_clickable((By.CSS_SELECTOR,'#J_waterfallPagination > div > div > a.pageConfirm')))

            input.clear()
            input.send_keys(page)
            submit.click()
        wait.until(
            EC.text_to_be_present_in_element((By.CSS_SELECTOR,"#J_waterfallPagination > div > div > span.page-cur"),str(page)))
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR,'#J_waterfallWrapper > div')))
        get_products()
    except TimeoutException:
        index_page(page)
from pyquery import PyQuery as pq
def get_products():
    """
    提取商品数据
    :return:
    """
    html = browser.page_source
    doc = pq(html)
    items = doc('#J_waterfallWrapper .item').items()
    item_nub=1
    for item in items:
        if item_nub<20:
            product={
                'image': item.find(' a > div.imgContainer > span > img').attr('src'),
                'price': item.find(' a .info .price ').text(),
                'title': item.find(' a .info .title').text(),
                'shopNick': item.find('a .info .shopName .shopNick').text(),
                'payNum': item.find('a .info .shopName .payNum').text()
            }
        else:
            product = {
                'image': item.find(' a > div.imgContainer > span > img').attr('data-ks-lazyload'),
                'price': item.find(' a .info .price ').text(),
                'title': item.find(' a .info .title').text(),
                'shopNick': item.find('a .info .shopName .shopNick').text(),
                'payNum': item.find('a .info .shopName .payNum').text()
            }
        print(product)
        save_to_mongo(product)
        item_nub+=1


MAX_PAGE =50
def main():
    for i in range(1,MAX_PAGE+1):
        index_page(i)

main()