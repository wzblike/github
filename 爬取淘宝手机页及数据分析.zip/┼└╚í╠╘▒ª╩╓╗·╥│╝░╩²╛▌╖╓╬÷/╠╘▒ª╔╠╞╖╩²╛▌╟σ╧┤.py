import pandas as pd
from retrying import retry
from concurrent.futures import ThreadPoolExecutor


phonedata = pd.read_excel("phone.xls")
import missingno as msno
msno.bar(phonedata.sample(len(phonedata)),figsize=(10,4))
half_count = len(phonedata)/2
phonedata = phonedata.dropna(thresh=half_count,axis=1)
phonedata = phonedata.drop_duplicates()
#取出这四列
data = phonedata[['payNum','price','title']]
# data.head()#默认前五行


data['payNum']=data['payNum'].str.split('人').str.get(0)
data['payNum'] = data['payNum'].astype('int')

data['price']=data['price'].str.replace("包邮","").str.replace("¥","")
data['price'] = data['price'].astype('float')
data['title']=data['title'].str.replace("\n","_")

# print(data)

title = data['title'].values.tolist()

import jieba
jieba.suggest_freq("旗舰店", tune=True)
jieba.suggest_freq("全网通", tune=True)
jieba.suggest_freq("骁龙865", tune=True)
jieba.suggest_freq("水滴全面屏", tune=True)
jieba.suggest_freq("12期", tune=True)
jieba.suggest_freq("\n", tune=True)
title_s = []
for line in title:
    title_cut = jieba.lcut(line)
    title_s.append(title_cut)

stopwords = pd.read_excel("stopword.xls")
stopwords = stopwords["stopword"].values.tolist()

#去除停用词
title_clean =[]
for line in title_s:
    line_clean =[]
    for word in line:
        if word ==' ' or word =='12' or word =='10':
            continue
        if word not in stopwords:
            line_clean.append(word)
    title_clean.append(line_clean)
#去重
title_clean_dist = []
for line in title_clean:
    line_dist =[]
    for word in line:
        if word not in line_dist:
            line_dist.append(word)
    title_clean_dist.append(line_dist)

#将title_clean_dist转化为一个list
allwords_clean_dist = []
for line in title_clean_dist:
    for word in line:
        allwords_clean_dist.append(word)
#把列表allwords_clean_dist 转换为数据框
df_allwords_clean_dist = pd.DataFrame({'allwords':allwords_clean_dist})

#对过滤_去重的词进行分类汇总
word_count =df_allwords_clean_dist["allwords"].value_counts().reset_index()
word_count.columns =["word","count"]
print(word_count)

#词云图
from wordcloud import WordCloud
import matplotlib.pyplot as plt
from matplotlib.pyplot import imread
plt.figure(figsize=(20,10))

pic = imread("abc.jpg")
w_c =WordCloud(font_path="1汉仪小麦体简.ttf",
               background_color="white",
               mask=pic,max_font_size=60,margin=1)
wc=w_c.fit_words({
    x[0]:x[1] for x in word_count.head(100).values
})
plt.imshow(wc,interpolation='bilinear')
plt.axis("off")


import numpy as np
i=0
w_s_sum = []
for w in word_count.word:
    s_list = []
    for t in title_clean_dist:
        if w in t:
            # print(i)
            # print(data['payNum'][i])
            s_list.append(data['payNum'][i])
        if i <50:
            i+=1
    w_s_sum.append(sum(s_list))#list求和

df_w_s_sum = pd.DataFrame({"w_s_sum":w_s_sum})

df_word_sum = pd.concat([word_count,df_w_s_sum],
                        axis=1,ignore_index=True)
df_word_sum.columns = ['word','count','w_s_sum']

#取付款人数最多前三十的词进行绘图
df_word_sum.sort_values('w_s_sum',inplace=True,ascending=True)#升序

df_w_s = df_word_sum.tail(30)#取最大的三十行

import matplotlib
from matplotlib import pyplot as plt

font = {'family':'SimHei'}#设置字体
matplotlib.rc('font',**font)

index = np.arange(df_w_s.word.size)
plt.figure(figsize=(6,12))
plt.barh(index,df_w_s.w_s_sum,color='purple',align='center',alpha=0.8)
plt.yticks(index,df_w_s.word,fontsize=11)

#添加数据标签
for y,x in zip(index,df_w_s.w_s_sum):
    plt.text(x,y,'%.0f'%x,ha='left',va='center',fontsize=11)

#商品购买价格
data_p = data[data['price'] > 200]
data_p = data_p[data_p['price'] < 12000]

plt.figure(figsize=(7,5))
plt.hist(data_p['price'],bins=12,color='purple')
plt.xlabel('价格',fontsize=12)
plt.ylabel('商品数量',fontsize=12)
plt.title('不同价格对应不同的商品数量分布',fontsize=15)

#不同价格区间的商品的平均销量分布:
#用qcut将price分为12组
data['group'] = pd.qcut(data_p['price'],8)
df_group = data['group'].value_counts().reset_index()

#以group列进行分类求销量的均值
df_s_g = data[['payNum','group']].groupby('group').mean().reset_index()

#绘制图形
index = np.arange(df_s_g['group'].size)
plt.figure(figsize=(8,4))
plt.bar(index,df_s_g['payNum'],color='purple')
plt.xticks(index,df_s_g['group'],fontsize=11,rotation=30)
plt.xlabel('组')
plt.ylabel('区间销量')
plt.title('不同价格区间的商品的平均销量')

#商品价格对商品销量的影响
fig,ax = plt.subplots()
ax.scatter(data_p['price'],data_p['payNum'],color='purple')
ax.set_xlabel('价格')
ax.set_ylabel('销量')
ax.set_title('商品价格对销量的影响')
plt.show()

ax.set_xlabel('价格')
ax.set_ylabel('销量')
ax.set_title('商品价格对销量的影响')
data['GMV'] = data['price'] * data['payNum']
import seaborn as sns
sns.regplot(x='price',y='GMV',data=data,color='purple')
plt.show()